﻿using IronXL;
using IronXL.Drawing.Charts;
using System;
using System.Windows.Forms;

namespace IronXL_FAQ_Ex
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            WorkBook wb = WorkBook.Load("Chart_Ex.xlsx");
            WorkSheet ws = wb.DefaultWorkSheet;

            var chart = ws.CreateChart(ChartType.Column, 10, 15, 25, 20);
           
            var series = chart.AddSeries("A2", "B2:D2");
            chart.AddSeries("A3", "B3:D3");
            chart.AddSeries("A4", "B4:D4");
            chart.AddSeries("A5", "B5:D5");
            chart.AddSeries("A6", "B6:D6");
            chart.AddSeries("A7", "B7:D7");

            chart.SetTitle("Column Chart");

            chart.SetLegendPosition(LegendPosition.Bottom);

            chart.Plot();

            wb.SaveAs("Exported_Column_Chart.xlsx");
        }

        private void button2_Click(object sender, EventArgs e)
        {

            WorkBook workbook = WorkBook.LoadCSV("Read_CSV_Ex.csv", fileFormat: ExcelFileFormat.XLSX, ListDelimiter: ",");
            WorkSheet ws = workbook.DefaultWorkSheet;
            workbook.SaveAs("Csv_To_Excel.xlsx");
        }
    }
}
